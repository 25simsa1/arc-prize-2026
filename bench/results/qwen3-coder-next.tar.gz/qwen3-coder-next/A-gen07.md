```python
def predict_event(meter_row63: str, action: str) -> str:
    # Game rule: GAME_OVER occurs if the row has exactly 15 trailing '5's (positions 49-63) and the action is ACTION6
    # Count trailing '5's from the end (right side); if count == 15 and action == "ACTION6", then GAME_OVER
    # Otherwise, NONE
    trailing_5s = 0
    for ch in reversed(meter_row63):
        if ch == '5':
            trailing_5s += 1
        else:
            break
    if trailing_5s == 15 and action == "ACTION6":
        return "GAME_OVER"
    return "NONE"
```