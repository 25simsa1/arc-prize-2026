```python
def predict_event(meter_row63: str, action: str) -> str:
    # The game ends if ACTION6 is taken when there are exactly two '5's in the bottom row.
    return "GAME_OVER" if meter_row63.count("5") == 2 and action == "ACTION6" else "NONE"
```